<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelOrder extends Model
{
    protected $table = 'order';
    protected $primarykey = 'ID_order';

    protected $useAutoIncrement = true;

    protected $returnType = 'array';
    protected $allowedFields = ['ID_order', 'NAMA_Barang'];
}
