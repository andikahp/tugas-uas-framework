<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelBarang extends Model
{
    protected $table = 'barang';
    protected $primarykey = 'id_barang';

    protected $useAutoIncrement = true;

    protected $returnType = 'array';

    protected $allowedField = ['id_barang', 'tipe_barang', 'nama_barang', 'tanggal_kirim', 'tanggal_sampai'];
}
