<?php

namespace App\Models;

use CodeIgniter\Model;

class NamaModel extends Model
{
    public function getData()
    {
        return 'Ini adalah Method getData dalam ProductModel';
    }
}
