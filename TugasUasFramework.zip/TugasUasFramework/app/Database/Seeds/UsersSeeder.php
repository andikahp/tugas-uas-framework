<?php

namespace App\Databases\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;

class UsersSeeder extends Seeder
{
    public function run()
    {
        $data =
            [
                'user_name'             => 'Admin',
                ';user_password'        => 'admin1'
            ];
        $this->db->table('users')->insert($data);
    }
}
