<?php

namespace App\Databases\Migrations;

use CodeIgniter\Database\Migration;

class Users extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'user_id'               => [
                'type'              => 'INT',
                'contraint'         => 11,
                'auto_increment'    => true
            ],
            'user_name'             => [
                'type'              => 'Varchar',
                'constraint'        => '100',
            ],
            'user_password'     => [
                'type'              => 'varchar',
                'constraint'        => '200',
            ]
        ]);
        $this->forge->addKey('user_id', true);
        $this->forge->createTable('users');
    }
    public function down()
    {
        $this->forge->dropTable('users');
    }
}
