<div class="table-responsive">
    <table class="table table-bordered" id="datatable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>ID Order</th>
                <th>Nama Barang</th>
                <th>Jenis Barang</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataorder as $do) : ?>
                <tr>
                    <td><?= $do['ID_order']; ?></td>
                    <td><?= $do['NAMA BARANG']; ?></td>
                    <td>
                        <a title="Edit" href="<? base_url(""); ?>" class="btn btn-info">Edit</a>
                        <a title="Delete" href="<? base_url(""); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus data ?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>