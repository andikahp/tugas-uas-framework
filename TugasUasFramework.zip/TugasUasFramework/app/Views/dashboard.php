<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <h1>Home - Dasboard</h1>
    <p>Ini adalah Website ekspedisi barang yang siap mengantar barang dengan harga yang sangat terjangkau. Kami menyediakan berbagai fitur tas untuk pengiriman. Dengan harga yang sangat murah, namun tetap tidak menomor duakan kualitas.</p>
</div>
<?= $this->endSection(); ?>