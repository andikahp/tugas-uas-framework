<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <h1>Order</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos quasi, provident cum quidem soluta adipisci totam tempore veritatis, recusandae delectus consectetur sint commodi cumque ex corporis. Illum voluptas id nihil.</p>
</div>
<?= $this->endSection(); ?>