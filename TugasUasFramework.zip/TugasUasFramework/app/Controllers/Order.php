<?php

namespace App\Controllers;

use App\Models\ModelOrder;

class Order extends BaseController
{
    protected $order;
    public function __construct()
    {
        $this->order = new ModelOrder();
    }
    public function index()
    {
        //echo "ini adalah method index controller order";
        //echo "<br><a href=' " . route_to('ordersaya') . " '>Link ke order saya</a>";
        //return view('order');
        $dataorder = $this->order->findAll();
        $data = [
            'title' => 'Order | Ekspedisi Barang'
        ];
        //echo view('layout/header', $data);
        //echo view('Order');
        //echo view('layout/footer');
        return view('order', $data);
    }
    public function kode_barang($param1 = '')
    {
        echo "ini adalah method detail controller order $param1";
    }
    public function nama_barang($param1 = '', $param2 = '')
    {
        echo "ini adalah method detail pada controller order kode $param1 barang";
    }
}
