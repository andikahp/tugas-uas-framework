<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Users_model;

class Users extends Controller
{
    public function index()
    {
        $model = new Users_model();
        $data['user']= $model->getUser();
        return view('user/index', $data);
    }
}
