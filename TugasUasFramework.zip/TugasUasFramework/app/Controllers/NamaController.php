<?php

namespace App\Controllers;

use App\Models\NamaModel;


class NamaController extends BaseController
{
    public function index()
    {
        $product = new NamaModel();
        echo $product->getData();
    }
}
