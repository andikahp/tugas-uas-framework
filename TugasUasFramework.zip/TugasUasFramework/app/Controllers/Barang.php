<?php

namespace App\Controllers;

class Barang extends BaseController
{
    public function index()
    {
        //echo "ini adalah method index controller harga";
        //echo "<br><a href=' " . route_to('detailharga') . " '>Link ke detail harga</a>";
        //return view('harga');
        $data = [
            'title' => 'Barang | Ekspedisi Barang'
        ];
        //echo view('layout/header', $data);
        //echo view('Barang');
        //echo view('layout/footer');
        return view('barang', $data);
    }
    public function nama_barang($param1 = '')
    {
        echo "ini adalah method detail controller nama $param1";
    }
    public function detail_barang($param1 = '', $param2 = '')
    {
        echo "ini adalah method detail pada controller nama detail $param1 barang";
    }
}
