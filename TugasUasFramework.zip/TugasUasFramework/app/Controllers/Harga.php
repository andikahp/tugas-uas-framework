<?php

namespace App\Controllers;

class Harga extends BaseController
{
    public function index()
    {
        //echo "ini adalah method index controller harga";
        //echo "<br><a href=' " . route_to('detailharga') . " '>Link ke detail harga</a>";
        //return view('harga');
        $data = [
            'title' => 'Harga | Ekspedisi Barang'
        ];
        //echo view('layout/header', $data);
        //echo view('Motor');
        //echo view('layout/footer');
        return view('harga', $data);
    }
    public function kode_barang($param1 = '')
    {
        echo "ini adalah method detail controller harga $param1";
    }
    public function detail_harga($param1 = '', $param2 = '')
    {
        echo "ini adalah method detail pada controller harga kode $param1 barang";
    }
}
