<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
	public function index()
	{
		//return view('welcome_message');
		$data = [
			'title' => 'Dashboard | Ekspedisi Barang'
		];
		//echo view('layout/header', $data);
		return view('dashboard', $data);
		//echo view('layout/footer');
	}
}
